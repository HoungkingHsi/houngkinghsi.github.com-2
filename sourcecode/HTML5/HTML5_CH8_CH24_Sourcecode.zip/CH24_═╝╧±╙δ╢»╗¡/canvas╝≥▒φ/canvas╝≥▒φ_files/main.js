(function() {
  var msnry; 
  
  window.onload = function() {
    msnry.layout();
    
    setTimeout(function() {
      document.getElementById('socialContainer').style.opacity = 1;  
    }, 500);  
  };
  
  msnry = new Masonry( '#items', {
    // options
    columnWidth: 360,
    itemSelector: '.item',
    gutter: 20 
  });  
  
})();
