/**
  * Author:Hungking Hsi
  * Email:imisslovelove@live.com
  * Date:2015-1-16 10:25:22
 **/

//创建数组
var x = new Array(1,20,8,12,6,7);
//输出数组元素
document.write("排序前的数组：" + x.join(",") + "<p>");
//按字符升序排序
x.sort();
document.write("没有使用比较函数排序后的数组：" + x.join(",") + "<p>");
//有比较函数的升序排序
x.sort(asc);
//升序比较函数
function asc(a,b){
	return b - a;
}
document.write("排序升序后的数组：" + x.join(",") + "<p>");
//有比较函数的降序排序
x.sort(des);
//降序比较函数
function des(a,b){
	return b - a;
}
document.write("排序降序后的数组：" + x.join(","));