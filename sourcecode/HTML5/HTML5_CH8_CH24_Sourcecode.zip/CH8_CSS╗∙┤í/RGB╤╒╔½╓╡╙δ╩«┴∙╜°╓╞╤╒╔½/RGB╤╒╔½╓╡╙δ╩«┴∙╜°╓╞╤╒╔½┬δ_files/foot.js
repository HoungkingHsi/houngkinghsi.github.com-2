// ͳ��
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F3aeca8011653b05560b6fd6e81e99c1f' type='text/javascript'%3E%3C/script%3E"));
