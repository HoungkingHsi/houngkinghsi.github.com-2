// ���
function ad(){
document.writeln('<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>');
document.writeln('<ins class="adsbygoogle"');
document.writeln('     style="display:block"');
document.writeln('     data-ad-client="ca-pub-2440711871479504"');
document.writeln('     data-ad-slot="9156178263"');
document.writeln('     data-ad-format="auto"></ins>');
document.writeln('<script>');
document.writeln('(adsbygoogle = window.adsbygoogle || []).push({});');
document.writeln('</script>');
}
